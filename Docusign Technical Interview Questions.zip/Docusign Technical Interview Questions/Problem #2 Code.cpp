// 2 out of 9 test-cases passed:
static long long int a, b, i, j, k;

template <typename T>
T Min (T a, T b)
{
    return b ^ ((a ^ b) & -(a < b));
}

template <typename T>
T getSequenceSum(T i, T j, T k) 
{
    long long int Sum = 0, iteration = i;
    
    //i -> j-1
    while (iteration != j) // 5 6 7 8
    {
        Sum = Sum + iteration;
        ++iteration;
    }
    
    //j -> k + 1
    while (iteration != k) //9 8 7 6 5 + {6} = k = sum
    {
        Sum = Sum + iteration;
        --iteration;
    }
    
    Sum = Sum + k; 
    return Sum;
}