// 7 out of 8 test-cases passed:
/*
- Complexity should be: O(n) and I didn't use any extra space so O(1).

- Instead of comparatively checking every single
  difference between the entire array, which will
  be 10^5 checks worst-case; we can start with the 
  minimum found and just subtract it to every element
  and find the greatest.
*/

template <typename T>
T maxDifference(std::vector <T> px) 
{
    int Difference = px[1] - px[0];
    int Min = px[0];
    
    int pxSize = px.size();
    for (int i = 1; i < pxSize; ++i)
    {
        if (px[i] - Min > Difference)
        {
            Difference = px[i] - Min; //greatest
        }
        
        if (px[i] < Min)
        {
            Min = px[i];
        }
    }
    return Difference;
} // 7/8 test-cases passed